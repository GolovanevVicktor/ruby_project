# Перевод Ruby on Rails Tutorial: пример приложения

Это пример приложения для
[*Ruby on Rails Tutorial*](http://railstutorial.org/)
by [Майкл Хартл](http://michaelhartl.com/).
